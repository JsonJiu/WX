#include "main.h"
#ifndef __PROCESS__H
#define __PROCESS__H


void Water_Speed(void);
void Data_Process(void);
void Water_Status(void);
void Get_Buffer_Init(void);
uint8_t Data_Verify(void);

#define xibanya 9000  //10pF 3k
#define shate_yijie 7000
#define shate_erjie 7000
#define shate_NB 13500
#define bilu 9000

#endif

