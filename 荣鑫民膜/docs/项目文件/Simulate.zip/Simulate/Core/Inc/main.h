/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.h
  * @brief          : Header for main.c file.
  *                   This file contains the common defines of the application.
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2025 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */

/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef __MAIN_H
#define __MAIN_H

#ifdef __cplusplus
extern "C" {
#endif

/* Includes ------------------------------------------------------------------*/
#include "stm32h5xx_hal.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
#include "string.h"
/* USER CODE END Includes */

/* Exported types ------------------------------------------------------------*/
/* USER CODE BEGIN ET */

/* USER CODE END ET */

/* Exported constants --------------------------------------------------------*/
/* USER CODE BEGIN EC */

/* USER CODE END EC */

/* Exported macro ------------------------------------------------------------*/
/* USER CODE BEGIN EM */

/* USER CODE END EM */

/* Exported functions prototypes ---------------------------------------------*/
void Error_Handler(void);

/* USER CODE BEGIN EFP */

/* USER CODE END EFP */

/* Private defines -----------------------------------------------------------*/
#define PWM_C_Pin GPIO_PIN_0
#define PWM_C_GPIO_Port GPIOA
#define INPUT_C_Pin GPIO_PIN_5
#define INPUT_C_GPIO_Port GPIOA
#define INPUT_C_EXTI_IRQn EXTI5_IRQn
#define INPUT_D_Pin GPIO_PIN_6
#define INPUT_D_GPIO_Port GPIOA
#define INPUT_D_EXTI_IRQn EXTI6_IRQn
#define PWM_D_Pin GPIO_PIN_7
#define PWM_D_GPIO_Port GPIOA
#define PWM_A_Pin GPIO_PIN_0
#define PWM_A_GPIO_Port GPIOB
#define PWM_B_Pin GPIO_PIN_1
#define PWM_B_GPIO_Port GPIOB
#define INPUT_A_Pin GPIO_PIN_2
#define INPUT_A_GPIO_Port GPIOB
#define INPUT_A_EXTI_IRQn EXTI2_IRQn
#define INPUT_B_Pin GPIO_PIN_10
#define INPUT_B_GPIO_Port GPIOB
#define INPUT_B_EXTI_IRQn EXTI10_IRQn

/* USER CODE BEGIN Private defines */

/* USER CODE END Private defines */

#ifdef __cplusplus
}
#endif

#endif /* __MAIN_H */
